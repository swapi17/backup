# image-upload-app
A simple image upload application using React and Node, which explores multiple ways to upload an image including using multer as a middleware, a CDN system and converting an image to a string and storing it.
