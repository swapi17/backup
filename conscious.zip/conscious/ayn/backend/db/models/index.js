const { Image } = require('./image.model');
const { User } = require('./user.model');


module.exports = {
    Image,
    User
}