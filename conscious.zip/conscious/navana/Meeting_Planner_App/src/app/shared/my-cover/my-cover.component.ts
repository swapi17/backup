import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-cover',
  templateUrl: './my-cover.component.html',
  styleUrls: ['./my-cover.component.css']
})
export class MyCoverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
