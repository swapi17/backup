import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-nav',
  templateUrl: './my-nav.component.html',
  styleUrls: ['./my-nav.component.css']
})
export class MyNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
